#!/bin/bash

# Install Angular CLI if not already installed
npm install -g @angular/cli

# Create new Angular project
ng new todo-frontend --routing --style=scss

# Navigate to project directory
cd todo-frontend

# Install required dependencies
npm install @angular/material @angular/cdk
npm install @angular/flex-layout
npm install bootstrap

# Create components
ng generate component components/todo-list
ng generate component components/todo-form
ng generate component components/todo-item

# Create services
ng generate service services/todo

# Create interfaces
mkdir src/app/interfaces
touch src/app/interfaces/todo.interface.ts 
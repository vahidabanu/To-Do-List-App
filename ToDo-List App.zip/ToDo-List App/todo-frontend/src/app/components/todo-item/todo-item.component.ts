import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Todo } from '../../interfaces/todo.interface';
import { TodoService } from '../../services/todo.service';

@Component({
  selector: 'app-todo-item',
  templateUrl: './todo-item.component.html',
  styleUrls: ['./todo-item.component.scss']
})
export class TodoItemComponent {
  @Input() todo!: Todo;
  @Output() todoUpdated = new EventEmitter<Todo>();
  @Output() todoDeleted = new EventEmitter<number>();

  editing = false;
  updating = false;
  deleting = false;
  error = '';

  constructor(private todoService: TodoService) {}

  toggleComplete(): void {
    this.updating = true;
    const updatedTodo = { ...this.todo, completed: !this.todo.completed };

    this.todoService.updateTodo(this.todo.id!, updatedTodo).subscribe({
      next: (todo) => {
        this.todoUpdated.emit(todo);
        this.updating = false;
      },
      error: (error) => {
        this.error = 'Error updating todo';
        this.updating = false;
        console.error('Error updating todo:', error);
      }
    });
  }

  deleteTodo(): void {
    if (confirm('Are you sure you want to delete this todo?')) {
      this.deleting = true;
      this.todoService.deleteTodo(this.todo.id!).subscribe({
        next: () => {
          this.todoDeleted.emit(this.todo.id);
          this.deleting = false;
        },
        error: (error) => {
          this.error = 'Error deleting todo';
          this.deleting = false;
          console.error('Error deleting todo:', error);
        }
      });
    }
  }
} 
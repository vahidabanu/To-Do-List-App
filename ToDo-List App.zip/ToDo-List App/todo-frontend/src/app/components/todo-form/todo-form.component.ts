import { Component, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TodoService } from '../../services/todo.service';
import { Todo } from '../../interfaces/todo.interface';

@Component({
  selector: 'app-todo-form',
  templateUrl: './todo-form.component.html',
  styleUrls: ['./todo-form.component.scss']
})
export class TodoFormComponent {
  @Output() todoCreated = new EventEmitter<Todo>();
  todoForm: FormGroup;
  submitting = false;
  error = '';

  constructor(
    private fb: FormBuilder,
    private todoService: TodoService
  ) {
    this.todoForm = this.fb.group({
      title: ['', [Validators.required, Validators.minLength(3)]],
      description: [''],
      completed: [false]
    });
  }

  onSubmit(): void {
    if (this.todoForm.valid) {
      this.submitting = true;
      const todo: Todo = this.todoForm.value;

      this.todoService.createTodo(todo).subscribe({
        next: (createdTodo) => {
          this.todoCreated.emit(createdTodo);
          this.todoForm.reset({ completed: false });
          this.submitting = false;
        },
        error: (error) => {
          this.error = 'Error creating todo';
          this.submitting = false;
          console.error('Error creating todo:', error);
        }
      });
    }
  }
} 